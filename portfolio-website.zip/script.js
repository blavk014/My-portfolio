// Service selection functionality
document.getElementById('services-select').addEventListener('change', function() {
  // Hide all service descriptions
  document.querySelectorAll('.service-desc').forEach(desc => {
    desc.classList.remove('active');
  });
  
  // Show selected service description
  const selectedValue = this.value;
  if (selectedValue) {
    document.getElementById(selectedValue).classList.add('active');
  }
});